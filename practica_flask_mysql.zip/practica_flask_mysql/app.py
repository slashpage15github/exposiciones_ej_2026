from flask import Flask, render_template, jsonify
import mysql.connector

app = Flask(__name__)

def conexion():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="1234",
        database="empresa"
    )

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/empleados")
def empleados():
    conn = conexion()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM empleados")
    datos = cursor.fetchall()
    conn.close()
    return jsonify(datos)

@app.route("/departamentos")
def departamentos():
    conn = conexion()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT departamento FROM empleados")
    datos = cursor.fetchall()
    conn.close()
    return jsonify([d[0] for d in datos])

@app.route("/puestos/<departamento>")
def puestos(departamento):
    conn = conexion()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT DISTINCT puesto FROM empleados WHERE departamento=%s",
        (departamento,)
    )
    datos = cursor.fetchall()
    conn.close()
    return jsonify([p[0] for p in datos])

@app.route("/ciudades/<puesto>")
def ciudades(puesto):
    conn = conexion()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT DISTINCT ciudad FROM empleados WHERE puesto=%s",
        (puesto,)
    )
    datos = cursor.fetchall()
    conn.close()
    return jsonify([c[0] for c in datos])

if __name__ == "__main__":
    app.run(debug=True)