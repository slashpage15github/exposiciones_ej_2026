CREATE DATABASE empresa;
USE empresa;

CREATE TABLE empleados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    departamento VARCHAR(100),
    puesto VARCHAR(100),
    ciudad VARCHAR(100)
);

INSERT INTO empleados (nombre, departamento, puesto, ciudad) VALUES
('Ana', 'Sistemas', 'Desarrollador', 'CDMX'),
('Luis', 'Sistemas', 'Soporte', 'Monterrey'),
('Carlos', 'RH', 'Reclutador', 'CDMX'),
('Marta', 'Ventas', 'Ejecutivo', 'Guadalajara'),
('Pedro', 'Ventas', 'Supervisor', 'Monterrey');

USE empresa;
SELECT * FROM empleados;

ALTER USER 'root'@'localhost' IDENTIFIED BY '1234';
FLUSH PRIVILEGES;

INSERT INTO empleados (nombre, departamento, puesto, ciudad) VALUES
('Laura', 'Finanzas', 'Contador', 'Monterrey'),
('Andrés', 'Marketing', 'Community Manager', 'Guadalajara'),
('Sofía', 'Sistemas', 'Analista', 'CDMX');